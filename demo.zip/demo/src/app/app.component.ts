import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name='abi';
  nameCreated=false;
  servers=['server1','server2']
  toggle=false;
 /* Event Binding */
  typeIt(event:Event){
    this.name=(<HTMLInputElement>event.target).value;
  } 

  createElement(){
    this.nameCreated=true;
    this.servers.push('serverInfinite');
  }
  toggleElement(){
    this.toggle=!this.toggle;
  }
  getcolor(){
    return this.nameCreated === true ? 'green':'red';
   }
}
