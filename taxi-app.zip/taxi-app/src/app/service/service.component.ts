import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css']
})
export class ServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  images=[
    "../assets/Images/1.png",
    "../assets/Images/2.png",
    "../assets/Images/3.png"
  ]
  taxi=[
    'Mini Taxi',
    'Prime Taxi',
    'Sedan Taxi'
  ]
  taxi_img1=[
    "../assets/Images/banner1.jpg",
    "../assets/Images/banner3.jpg",
    "../assets/Images/banner4.jpg",
    "../assets/Images/banner2.jpg"
  ]
  taxi_img2=[
    "../assets/Images/banner5.jpg",
    "../assets/Images/banner4.jpg",
    "../assets/Images/banner2.jpg",
    "../assets/Images/banner3.jpg"
    
   
  ]

  img1_txt=[
    'Top Rated Drivers',
    'Safety Journey',
    'Without Peak Pricing',
    'Fast And Secure'
  ]
  img2_txt=[
    'Lowest Rates',
    'Best Quality Cabs',
    'Online Booking',
    '24/7 Cab Service'
  ]
}
 