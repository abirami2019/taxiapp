import { Component, OnInit } from '@angular/core';

declare var $: any;
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  
  constructor() {
     
   }

  ngOnInit() {

    $(window).scroll(function(){

      $({ countNum: $('.code1').html() }).animate({ countNum: 324},
        {
        duration: 2000,
        easing: 'linear',
        step: function () {
        $('.code1').html(Math.floor(this.countNum));
        },
        complete: function () {
        $('.code1').html(this.countNum);
        //alert('finished');
        }
    });

    $({ countNum: $('.code2').html() }).animate({ countNum: 543},
      {
      duration: 2000,
      easing: 'linear',
      step: function () {
      $('.code2').html(Math.floor(this.countNum));
      },
      complete: function () {
      $('.code2').html(this.countNum);
      //alert('finished');
      }
  });
  $({ countNum: $('.code3').html() }).animate({ countNum: 434},
    {
    duration: 2000,
    easing: 'linear',
    step: function () {
    $('.code3').html(Math.floor(this.countNum));
    },
    complete: function () {
    $('.code3').html(this.countNum);
    //alert('finished');
    }
});

$({ countNum: $('.code4').html() }).animate({ countNum: 234},
  {
  duration: 2000,
  easing: 'linear',
  step: function () {
  $('.code4').html(Math.floor(this.countNum));
  },
  complete: function () {
  $('.code4').html(this.countNum);
  //alert('finished');
  }
});

    });
   

   

        
        



  }

 
  images=[
    "../assets/Images/1.png",
    "../assets/Images/2.png",
    "../assets/Images/3.png"
  ];
taxi=[
  'Mini Taxi',
  'Prime Taxi',
  'Sedan Taxi'
];

teams=[
  "../assets/Images/team1.jpg",
    "../assets/Images/team2.jpg",
    "../assets/Images/team3.jpg",
    "../assets/Images/team4.jpg"
]
team_name=[
  'JOHN SMITH',
  'LAURA HILL',
  'SMITH KEVIN',
  'THOMSO'
] 

phone_numbers=[
  '12(00) 123 1234',
  '12(00) 123 1235',
  '12(00) 123 1236',
  '12(00) 123 1237'
]

}
