import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CarouselComponent } from './carousel/carousel.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DialogComponent } from './dialog/dialog.component';
import { AboutComponent } from './about/about.component';
import { ServiceComponent } from './service/service.component';
import { BookingComponent } from './booking/booking.component';
import { ContactComponent } from './contact/contact.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ImageComponent } from './image/image.component';
import { WelcomeComponent } from './welcome/welcome.component'; 
import { AgmCoreModule } from '@agm/core';
import {FormsModule} from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CarouselComponent,
    DialogComponent,
    AboutComponent,
    ServiceComponent,
    BookingComponent,
    ContactComponent,
    NavbarComponent,
    ImageComponent,
    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,NgbModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyA_w-Rq3DSrCqxCO2uk51w3bSCERnMEhcg'
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
