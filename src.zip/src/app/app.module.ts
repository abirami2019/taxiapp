import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AuthGuard } from './services/auth.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent, HeaderDashboardDirective } from './dashboard/dashboard.component';
import { HeaderComponent, DFModalDirective, DFSearchBarModalDirective } from './header/header.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { FooterComponent } from './footer/footer.component';
import { WebService } from './services/web.service';
import { SharedService } from './services/shared.service';
import { AdalService, AdalGuard } from 'adal-angular4';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LoaderService } from './services/loader.service';
import { LoaderInterceptor } from './services/loader.intercepter';
import { AboutdfComponent } from './aboutdf/aboutdf.component';
import { ScrollSpyDirective } from './Directives/scroll-spy.directive';

import { MatExpansionModule } from '@angular/material/expansion';
import { RandPipe } from './services/rand.pipe';
import { DigitalfinanceComponent } from './solutions/enterpriseservices/digitalfinance/digitalfinance.component';
import { MatTableModule, MatSortModule, MatPaginatorModule } from '@angular/material';
import { AssetsAnalyticsComponent } from './dfassets/assets-analytics/assets-analytics.component';
import { AssetsAutomationComponent } from './dfassets/assets-automation/assets-automation.component';
import { MatchHeightDirective } from './Directives/matchheight.directive';
import { ResourceCenterComponent } from './resourceCenter/resource-center.component';
import { KnowledgeAssetComponent } from './dfassets/knowledge-asset/knowledge-asset.component';
import { PharmacovigilanceComponent } from './solutions/ls/pharmacovigilance/pharmacovigilance.component';
import { DigitalMarketingComponent } from './solutions/cmt/DigitalMarketing/digitalmarketing.component';
import { PopupmodalDirective } from './Directives/popupmodal.directive';
import { SearchComponent } from './search/search.component';
import { KycComponent } from './solutions/bfs/kyc/kyc.component';
import { DownloadableComponent } from './reusableComponents/downlodable/downloadable.component';
import { BookmarkComponent } from './reusableComponents/bookmark/bookmark.component';
import { RecentlyvisitedpageComponent } from './reusableComponents/recentlyvisitedpage/recentlyvisitedpage.component';
import { SearchboxComponent } from './reusableComponents/searchbox/searchbox.component';
import { UsergeneratedcontentComponent } from './solutions/cmt/usergeneratedcontent/usergeneratedcontent.component';
import { RevenuecyclemgmtComponent } from './solutions/healthcare/revenuecyclemgmt/revenuecyclemgmt.component';
import { MortgageoperationsComponent } from './solutions/bfs/mortgageoperations/mortgageoperations.component';
import { PCOpsComponent } from './solutions/insurance/pc-ops/pc-ops.component';
import { LAOpsComponent } from './solutions/insurance/la-ops/la-ops.component';
import { LocationBasedServicesComponent } from './solutions/cmt/location-based-services/location-based-services.component';
import { NextGenSalesCCComponent } from './solutions/enterpriseservices/next-gen-sales-cc/next-gen-sales-cc.component';
import { HcpayeropsComponent } from './solutions/healthcare/hcpayerops/hcpayerops.component';
import { RetailopsComponent } from './solutions/rhcg/retailops/retailops.component';
import { ManufacturingopsComponent } from './solutions/mleu/manufacturingops/manufacturingops.component';
import { DataintegritycontrolComponent } from './solutions/bfs/dataintegritycontrol/dataintegritycontrol.component';
import { ComplaintsmanagementComponent } from './solutions/ls/complaintsmanagement/complaintsmanagement.component';
import { BrokeragefeesandbillingComponent } from './solutions/bfs/brokeragefeesandbilling/brokeragefeesandbilling.component';
import { AssetwealthmanagementComponent } from './solutions/bfs/assetwealthmanagement/assetwealthmanagement.component';
import { RetailbankingComponent } from './solutions/bfs/retailbanking/retailbanking.component';
import { EnterpriseautomationComponent } from './solutions/ipa/enterpriseautomation/enterpriseautomation.component';
import { OperationalanalyticsComponent } from './solutions/ipa/operationalanalytics/operationalanalytics.component';
import { ProcessConsultingComponent } from './solutions/enterpriseservices/process-consulting/process-consulting.component';
import { BrandGeneratedContentComponent } from './solutions/cmt/brand-generated-content/brand-generated-content.component';
import { DigitalCustomerExperienceComponent } from './solutions/cmt/digital-customer-experience/digital-customer-experience.component';
import { OrderToCashComponent } from './solutions/enterpriseservices/digitalfinance/order-to-cash/order-to-cash.component';
import { RecordToReportComponent } from './solutions/enterpriseservices/digitalfinance/record-to-report/record-to-report.component';
import { DfTenetsComponent } from './reusableComponents/df-tenets/df-tenets.component';
import { ClinicalDataManagementComponent } from './solutions/ls/clinical-data-management/clinical-data-management.component';
import {
  TermsConditionsmodalComponent,
  DFDownloadModalDirective
} from './reusableComponents/terms-conditionsmodal/terms-conditionsmodal.component';
import { DummyComponent } from './solutions/bfs/dummy/dummy.component';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderDashboardDirective,
    HeaderComponent,
    NotFoundComponent,
    FooterComponent,
    AboutdfComponent,
    ScrollSpyDirective,
    RandPipe,
    DigitalfinanceComponent,
    DFModalDirective,
    DFSearchBarModalDirective,
    AssetsAnalyticsComponent,
    AssetsAutomationComponent,
    DFDownloadModalDirective,
    MatchHeightDirective,
    ResourceCenterComponent,
    KnowledgeAssetComponent,
    PharmacovigilanceComponent,
    PopupmodalDirective,
    DigitalMarketingComponent,
    SearchComponent,
    KycComponent,
    DownloadableComponent,
    BookmarkComponent,
    RecentlyvisitedpageComponent,
    SearchboxComponent,
    UsergeneratedcontentComponent,
    RevenuecyclemgmtComponent,
    MortgageoperationsComponent,
    PCOpsComponent,
    LAOpsComponent,
    LocationBasedServicesComponent,
    NextGenSalesCCComponent,
    HcpayeropsComponent,
    RetailopsComponent,
    ManufacturingopsComponent,
    DataintegritycontrolComponent,
    ComplaintsmanagementComponent,
    BrokeragefeesandbillingComponent,
    AssetwealthmanagementComponent,
    RetailbankingComponent,
    EnterpriseautomationComponent,
    OperationalanalyticsComponent,
    ProcessConsultingComponent,
    BrandGeneratedContentComponent,
    DigitalCustomerExperienceComponent,
    OrderToCashComponent,
    RecordToReportComponent,
    DfTenetsComponent,
    ClinicalDataManagementComponent,
    TermsConditionsmodalComponent,
    DummyComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    CarouselModule,
    MatExpansionModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule
  ],
  providers: [
    AuthGuard,
    Title,
    WebService,
    SharedService,
    AdalService,
    AdalGuard,
    LoaderService,
    DatePipe,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
