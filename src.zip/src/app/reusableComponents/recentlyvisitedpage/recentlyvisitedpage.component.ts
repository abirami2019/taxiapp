import { Component, OnInit, Input } from '@angular/core';
import { WebService } from 'src/app/services/web.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';

@Component({
  selector: 'app-recentlyvisitedpage',
  templateUrl: './recentlyvisitedpage.component.html',
  styleUrls: ['./recentlyvisitedpage.component.css']
})
export class RecentlyvisitedpageComponent implements OnInit {
  @Input() pageTitle1: string;
  @Input() pageTitle2: string;

  constructor(private webService: WebService, private route: Router) {}

  ngOnInit() {
    let pageName;
    pageName = _.startCase(this.pageTitle1);
    try {
      if (this.pageTitle2 != undefined) {
        pageName = _.startCase(this.pageTitle1) + ' - ' + _.startCase(this.pageTitle2);
      }
      const reqURI = this.route.url.includes('#') ? '/dashboard' : this.route.url;
      this.webService.saveRecentlyVisitedPageDetails(pageName, reqURI).subscribe(body => {
        if (body[0] == 'Update') {
          this.webService.updateSPList('UserBasedContent', body[2], body[1]).subscribe(
            result => {},
            error => {
              console.log('Error occured while updating recently visited page details');
            }
          );
        } else if (body[0] == 'Post') {
          this.webService.postDataToSP('UserBasedContent', body[1]).subscribe(
            result => {},
            error => {
              console.log('Error occured while inserting recently visited page details');
            }
          );
        }
      });
    } catch (error) {
      console.log('Error Message : ' + error);
    }
  }
}
