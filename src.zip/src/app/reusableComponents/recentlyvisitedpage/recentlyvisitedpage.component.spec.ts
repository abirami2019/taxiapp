import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentlyvisitedpageComponent } from './recentlyvisitedpage.component';

describe('RecentlyvisitedpageComponent', () => {
  let component: RecentlyvisitedpageComponent;
  let fixture: ComponentFixture<RecentlyvisitedpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecentlyvisitedpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentlyvisitedpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
