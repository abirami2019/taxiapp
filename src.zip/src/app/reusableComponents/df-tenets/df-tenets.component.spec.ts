import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DfTenetsComponent } from './df-tenets.component';

describe('DfTenetsComponent', () => {
  let component: DfTenetsComponent;
  let fixture: ComponentFixture<DfTenetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DfTenetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DfTenetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
