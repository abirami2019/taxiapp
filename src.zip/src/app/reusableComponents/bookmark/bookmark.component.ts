import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import * as _ from 'lodash';
import { WebService } from '../../services/web.service';

@Component({
  selector: 'app-bookmark',
  templateUrl: './bookmark.component.html',
  styleUrls: ['./bookmark.component.css']
})
export class BookmarkComponent implements OnInit {
  @Input() pageTitle1: string;
  @Input() pageTitle2: string;
  isBookmarked = false;
  bookmarkAlertMsg = false;
  bookmarkLimit = environment.myBookmarksCount;
  itemId: number;
  pageName: string;
  constructor(private webService: WebService, private route: Router) {}

  ngOnInit() {
    this.pageName = _.startCase(this.pageTitle1);
    if (this.pageTitle2 != undefined) {
      this.pageName = _.startCase(this.pageTitle1) + ' - ' + _.startCase(this.pageTitle2);
    }
    const urlQueryString = this.route.url.split('/');
    this.getOnloadData();
  }

  /* check the current page has bookmarked or default page */
  getOnloadData() {
    const getDefaultPageQuery = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    this.webService.getdata('UserBasedContent', getDefaultPageQuery).subscribe(res => {
      if (res['value'].length > 0) {
        this.itemId = res['value'][0]['ID'];
        const bookmarkedData = JSON.parse(res['value'][0]['BookmarkDetails']);
        if (bookmarkedData != null && bookmarkedData.length > 0) {
          this.isBookmarked = _.filter(bookmarkedData, ['url', this.route.url]).length > 0 ? true : false;
        }
      }
    });
  }

  bookmarkPage() {
    const queryParam = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    this.webService.getdata('UserBasedContent', queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        const itemId = data['value'][0].ID;
        const bookmarkedData =
          JSON.parse(data['value'][0]['BookmarkDetails']) == null
            ? []
            : _.slice(JSON.parse(data['value'][0]['BookmarkDetails']), 0, this.bookmarkLimit);

        const filteredData = _.filter(bookmarkedData, ['url', this.route.url]);
        if (!this.isBookmarked && bookmarkedData.length >= this.bookmarkLimit) {
          this.bookmarkAlertMsg = true;
          setTimeout(() => {
            this.bookmarkAlertMsg = false;
          }, 3000);
        } else if (filteredData.length > 0) {
          this.isBookmarked = false;
          _.remove(bookmarkedData, function(n: any) {
            return n.url == filteredData[0]['url'];
          });
        } else {
          this.isBookmarked = true;
          const index = bookmarkedData.length >= this.bookmarkLimit ? this.bookmarkLimit - 1 : bookmarkedData.length;
          bookmarkedData[index] = {
            key: this.pageName,
            url: this.route.url
          };
        }
        const body = {
          __metadata: { type: 'SP.Data.UserBasedContentListItem' },
          Title: this.webService.getUserName + '\'s bookmark',
          UserId: this.webService.getUserName,
          BookmarkDetails: JSON.stringify(bookmarkedData)
        };
        this.webService.updateSPList('UserBasedContent', itemId, body).subscribe(result => {});
      } else {
        const currentBookmark = [];
        currentBookmark.push({
          key: this.pageName,
          url: this.route.url
        });
        const body = {
          __metadata: { type: 'SP.Data.UserBasedContentListItem' },
          Title: this.webService.getUserInfo().profile.name,
          UserId: this.webService.getUserName,
          BookmarkDetails: JSON.stringify(currentBookmark)
        };
        this.webService.postDataToSP('UserBasedContent', body).subscribe(
          result => {},
          () => {
            this.getOnloadData();
          }
        );
      }
    });
  }
}
