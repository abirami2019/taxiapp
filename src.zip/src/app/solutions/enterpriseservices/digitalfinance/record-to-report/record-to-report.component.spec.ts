import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecordToReportComponent } from './record-to-report.component';

describe('RecordToReportComponent', () => {
  let component: RecordToReportComponent;
  let fixture: ComponentFixture<RecordToReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecordToReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecordToReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
