import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RevenuecyclemgmtComponent } from './revenuecyclemgmt.component';

describe('RevenuecyclemgmtComponent', () => {
  let component: RevenuecyclemgmtComponent;
  let fixture: ComponentFixture<RevenuecyclemgmtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RevenuecyclemgmtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RevenuecyclemgmtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
