import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HcpayeropsComponent } from './hcpayerops.component';

describe('HcpayeropsComponent', () => {
  let component: HcpayeropsComponent;
  let fixture: ComponentFixture<HcpayeropsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HcpayeropsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HcpayeropsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
