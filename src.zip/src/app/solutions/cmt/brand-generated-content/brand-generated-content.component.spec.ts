import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandGeneratedContentComponent } from './brand-generated-content.component';

describe('BrandGeneratedContentComponent', () => {
  let component: BrandGeneratedContentComponent;
  let fixture: ComponentFixture<BrandGeneratedContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandGeneratedContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandGeneratedContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
