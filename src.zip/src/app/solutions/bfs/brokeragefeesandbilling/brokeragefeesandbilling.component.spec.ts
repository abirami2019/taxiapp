import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokeragefeesandbillingComponent } from './brokeragefeesandbilling.component';

describe('BrokeragefeesandbillingComponent', () => {
  let component: BrokeragefeesandbillingComponent;
  let fixture: ComponentFixture<BrokeragefeesandbillingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokeragefeesandbillingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokeragefeesandbillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
