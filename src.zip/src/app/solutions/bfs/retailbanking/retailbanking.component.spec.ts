import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailbankingComponent } from './retailbanking.component';

describe('RetailbankingComponent', () => {
  let component: RetailbankingComponent;
  let fixture: ComponentFixture<RetailbankingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailbankingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailbankingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
