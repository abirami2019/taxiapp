import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnterpriseautomationComponent } from './enterpriseautomation.component';

describe('EnterpriseautomationComponent', () => {
  let component: EnterpriseautomationComponent;
  let fixture: ComponentFixture<EnterpriseautomationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnterpriseautomationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterpriseautomationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
