import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailopsComponent } from './retailops.component';

describe('RetailopsComponent', () => {
  let component: RetailopsComponent;
  let fixture: ComponentFixture<RetailopsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailopsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
