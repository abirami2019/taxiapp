import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PCOpsComponent } from './pc-ops.component';

describe('PCOpsComponent', () => {
  let component: PCOpsComponent;
  let fixture: ComponentFixture<PCOpsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PCOpsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PCOpsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
