import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LAOpsComponent } from './la-ops.component';

describe('LAOpsComponent', () => {
  let component: LAOpsComponent;
  let fixture: ComponentFixture<LAOpsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LAOpsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LAOpsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
