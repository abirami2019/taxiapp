import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintsmanagementComponent } from './complaintsmanagement.component';

describe('ComplaintsmanagementComponent', () => {
  let component: ComplaintsmanagementComponent;
  let fixture: ComponentFixture<ComplaintsmanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintsmanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintsmanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
