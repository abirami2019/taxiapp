import { Component, OnInit, ViewEncapsulation, Directive, OnDestroy, AfterViewInit, HostListener, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { WebService } from '../services/web.service';
import { SharedService } from '../services/shared.service';
import { LoaderService } from '../services/loader.service';
import { environment } from '../../environments/environment';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { trigger, style, transition, animate } from '@angular/animations';
import * as _ from 'lodash';
import { CarouselComponent } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('enterAnimation', [
      transition(':enter', [style({ opacity: 0 }), animate('500ms', style({ opacity: 1 }))]),
      transition(':leave', [style({ opacity: 1 }), animate('0ms', style({ opacity: 0 }))])
    ])
  ]
})
export class DashboardComponent implements OnInit {
  @ViewChild('carousel') carousel: CarouselComponent;
  menuArr = [];
  popSearch = ['Mortgage Services', 'KYC', 'Ragulatory Compliance', 'Retail Banking Ops'];
  tabHome1 = ['Assets', 'Solutions'];
  tabWhatsNew = ['What\'s New', 'Industry News'];
  showLessOrMore = false;
  innerWidth: number;
  showMoreContent: number;
  selectedTabHome1 = 0;
  selectedTabHome2 = 0;
  selectedTabHome3 = 0;
  selectedTabWhatsNew = 0;
  dashBoardContent = [];
  searchContent: Array<Object>;
  popuplarSearchList: Array<Object>;
  advSearch = new FormGroup({
    searchString: new FormControl('', [Validators.required, Validators.minLength(4)])
  });
  selectedMobTab = 'myBookmarkedPages';
  bookmarkedData = [];
  recentlyVisitedData = [];
  defaultSelectedBookmark = 'default';
  defaultSelectedFrequentPage = 'default';
  serachTitleList = [];
  filteredData: Array<string>;
  baseUrl = environment.config.spUrl + environment.config.spSiteCollection;
  botResumes = new Array();
  downloadData = new Array();
  noOfDownloads = 0;
  splitData: Array<string>;
  processHaloCount = 0;
  cjmCount = 0;
  topCJMServiceName: string;
  topProcessHaloServiceName: string;

  customOptions: any = {
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: true,
    navSpeed: 700,
    navText: ['<h5 class="greenArrow fas fa-angle-left"></h5>', '<h5 class="greenArrow fas fa-angle-right"></h5>'],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 1
      },
      740: {
        items: 1
      },
      940: {
        items: 1
      }
    },
    nav: true
  };
  customOptions2: any = {
    dots: false,
    navSpeed: 700,
    navText: ['<h5 class="greenArrow fas fa-angle-left"></h5>', '<h5 class="greenArrow fas fa-angle-right"></h5>'],
    responsive: {
      0: {
        items: 4
      },
      400: {
        items: 4
      },
      740: {
        items: 5
      },
      940: {
        items: 5
      }
    },
    nav: true
  };

  constructor(
    private titleServices: Title,
    private route: Router,
    private webService: WebService,
    public loaderService: LoaderService,
    private shareService: SharedService
  ) {
    this.titleServices.setTitle('Dashboard');
  }

  ngOnInit() {
    if (this.webService.authenticate) {
      // tslint:disable-next-line: max-line-length
      const getDefaultPageQuery = '?$filter=UserId eq \'' + this.webService.getUserInfo().userName + '\'';
      this.webService.getdata('UserBasedContent', getDefaultPageQuery).subscribe(res => {
        if (res['value'].length > 0 && sessionStorage.getItem('firstTimeLogin') == null) {
          sessionStorage.setItem('firstTimeLogin', 'true');
          this.route.navigateByUrl(res['value'][0]['DefaultPageUrl']);
          return;
        } else if (
          sessionStorage.getItem('redirectUri') != null &&
          sessionStorage.getItem('redirectUri') != '/null' &&
          sessionStorage.getItem('redirectUri') != 'null'
        ) {
          this.route.navigateByUrl(sessionStorage.getItem('redirectUri'));
        } else {
          this.route.navigate(['/', 'dashboard']);
        }
      });
    }
    this.getAutoCompleteData();
    const dashboardPageLists = [
      'dashboard_industryItems',
      'dashboard_newItems',
      'dashboard_creating_impact',
      'dashboard_casestudies_list',
      'current_content_count',
      'dashboard_analytics_content'
    ];
    this.getdata('Solutions');
    this.showMoreOrLess(false);
    this.getMyAssetSolutionData(['my_assets_dashboard', 'my_solutions_dashboard', 'my_bookmarked_data']);
    this.getTrendingAssets('TrendingAssets');
    this.getTrendingSolutions('TrendingSolutions');
    this.getdataFromSP(dashboardPageLists);
    this.popuplarSearchTerm();
    this.innerWidth = window.innerWidth;
    this.getRecentlyVisitedPageDetails();
    const queryParams1 = '';
    this.downloadData['Solution'] = [];
    this.downloadData['Asset'] = [];
    this.downloadData['TopAsset'] = [];
    this.webService.getdata('DownloadDetails', queryParams1).subscribe(data => {
      _.forEach(data['value'], val => {
        if (val.documentType == 'Solution') {
          this.downloadData['Solution'].push(val);
        } else if (val.documentType == 'Asset') {
          this.downloadData['Asset'].push(val);
        }
      });
      let cjm = 0;
      let halo = 0;
      _.forEach(this.downloadData['Solution'], val => {
        if (val.Title == 'CJM') {
          // cjm = cjm + val.downloadCount;
          if (cjm < val.downloadCount) {
            cjm = val.downloadCount;
            this.topCJMServiceName = val.serviceName;
          }
        }
        if (val.Title == 'Process Halo') {
          // halo = halo + val.downloadCount;
          if (halo < val.downloadCount) {
            halo = val.downloadCount;
            this.topProcessHaloServiceName = val.serviceName;
          }
        }
      });
      this.noOfDownloads = this.downloadData['Asset'].length;
      this.cjmCount = cjm;
      this.processHaloCount = halo;
      this.downloadData['TopAsset'] = _.slice(_.orderBy(this.downloadData['Asset'], ['downloadCount'], 'desc'), 0, 3);
      // _.slice(myData, 0, environment.myAssetsCount), 4
    });
    // this.splitData[] = this.filteredData = _.filter(this.serachTitleList, function(o) {
    //   return _.includes(o.toLowerCase(), searchText.toLowerCase());
    // });
    const listname = 'DetailPage';
    const queryParams = '?$filter=solutionDepends eq \'Automation\' or solutionDepends eq \'Analytics\'&$top=500';
    this.webService.getdata(listname, queryParams).subscribe(data => {
      this.botResumes = data['value'];
    });
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
  }

  /* Returns Children's list of given input  */
  getdata(filterMenuItem: any) {
    const listname = 'NaviList';
    const queryParams = '';
    this.webService.getdata(listname, queryParams).subscribe(data => {
      const assetArr = this.shareService.getTreelist(data, filterMenuItem);
      const res = _.sortedUniq(this.shareService.traverse(assetArr));
      _.remove(res, function(n) {
        return n.page == 0;
      });
      this.menuArr[filterMenuItem] = _.chunk(_.sampleSize(res, 8), 4);
    });
  }

  /* Get data from SharePoint */
  getdataFromSP(tabName) {
    _.forEach(tabName, val => {
      const listname = 'ContentLibrary';
      const queryParams = '?$filter=Title eq \'' + val + '\'&$orderby=sort_order';
      this.webService.getdata(listname, queryParams).subscribe(data => {
        switch (val) {
          case 'my_assets_dashboard':
          case 'my_solutions_dashboard':
            this.dashBoardContent[val] = _.chunk(data['value'], 4);
            break;
          case 'dashboard_casestudies_list':
            this.dashBoardContent[val] = data['value'];
            const caseStudyListItem = [];
            _.forEach(this.dashBoardContent[val], (list: any) => {
              caseStudyListItem.push('dashboard_casestudy_' + list.SmallText);
            });
            this.getdataFromSP(caseStudyListItem);
            break;
          default:
            this.dashBoardContent[val] = data['value'];
            break;
        }
      });
    });
  }

  /* To get MyAssets and MySolutions data for Dashboard page */
  getMyAssetSolutionData(items) {
    let myData = [];
    const listName = 'UserBasedContent';
    const queryParam = '?$filter=UserId eq \'' + this.webService.getUserInfo().userName + '\'';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      _.forEach(items, val => {
        switch (val) {
          case 'my_assets_dashboard':
            /* To get MyAssets data from SP */
            if (data['value'].length > 0 && data['value'][0].MyAssets != null) {
              myData = _.orderBy(JSON.parse(data['value'][0].MyAssets), ['count'], 'desc');
              this.dashBoardContent[val] = _.chunk(_.slice(myData, 0, environment.myAssetsCount), 4);
            } else {
              /* Dafault Items will be added for MyAssets section */
              this.getTrendingAssets('my_assets_dashboard');
            }
            break;

          case 'my_solutions_dashboard':
            /* To get MySolutions data from SP */
            if (data['value'].length > 0 && data['value'][0].MySolutions != null) {
              myData = _.orderBy(JSON.parse(data['value'][0].MySolutions), ['count'], 'desc');
              this.dashBoardContent[val] = _.chunk(_.slice(myData, 0, environment.mySolutionsCount), 4);
            } else {
              /* Dafault Items will be added for MySolutions section */
              this.getTrendingSolutions('my_solutions_dashboard');
            }
            break;
          case 'my_bookmarked_data':
            /* To get the Bookmarked data from SP in mobile & tab view */
            if (data['value'].length > 0 && data['value'][0].BookmarkDetails != null) {
              this.bookmarkedData['chunkData'] =
                JSON.parse(data['value'][0]['BookmarkDetails']) == null ? [] : _.chunk(JSON.parse(data['value'][0]['BookmarkDetails']), 4);
              this.bookmarkedData['rawData'] =
                JSON.parse(data['value'][0]['BookmarkDetails']) == null ? [] : JSON.parse(data['value'][0]['BookmarkDetails']);
            }
            break;
          default:
            break;
        }
      });
    });
  }

  /* To get the Trending Assets and Trending Solutions from SP */
  getTrendingAssets(param) {
    const listName = 'DetailPage';
    const queryParam = '';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        const trendingList = _.orderBy(data['value'], ['AssetVisitCount'], 'desc');
        this.dashBoardContent[param] = _.chunk(_.slice(trendingList, 0, environment.trendingAssetsount), 4);
      }
    });
  }

  getTrendingSolutions(param) {
    let trendingList = [];
    const listName = 'ContentLibrary';
    const queryParam = '?$filter=Title eq \'trending_solutions_dashboard\'';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        if (data['value'][0].trendingData != null && data['value'][0].trendingData != '') {
          trendingList = _.orderBy(JSON.parse(data['value'][0].trendingData), ['count'], 'desc');
          this.dashBoardContent[param] = _.chunk(_.slice(trendingList, 0, environment.trendingSolutionsCount), 4);
        } else {
          if (data['value'][0].defaultData != null && data['value'][0].defaultData != '') {
            trendingList = _.orderBy(JSON.parse(data['value'][0].defaultData), ['count'], 'desc');
            this.dashBoardContent[param] = _.chunk(_.slice(trendingList, 0, environment.trendingSolutionsCount), 4);
          }
        }
      }
    });
  }

  /* Limit the text size on displaying */
  showMoreOrLess(val: any) {
    this.showLessOrMore = val ? false : true;
    this.showMoreContent = val ? 0 : 200;
  }

  searchTerm(searchText) {
    this.filteredData = [];
    if (searchText == '' || searchText == undefined) {
      // this.showNoContent = false;
      return;
    }
    this.filteredData = _.filter(this.serachTitleList, function(o) {
      return _.includes(o.toLowerCase(), searchText.toLowerCase());
    });
    // this.showNoContent = this.filteredData.length > 0 ? false : true;
  }

  /* Get search text from form */
  searchForm(text: any) {
    if (text.searchString.length <= 3) {
      return;
    }
    this.searchFromSP(text.searchString);
  }

  /* Update Search text in Sharepoint List and run search query IF exists*/
  searchFromSP(searchText) {
    searchText = typeof searchText == 'object' ? searchText.searchString : searchText;
    if (searchText.length < 2) {
      return;
    }
    this.route.navigateByUrl('/search?t=' + searchText);
  }

  /* To get the Auto Complete List for Advanced Search field */
  getAutoCompleteData() {
    const autoCompleteQuery = '?$select=Title';
    this.webService.getdata('searchList', autoCompleteQuery).subscribe(data => {
      if (data['value'] && data['value'].length > 0) {
        _.forEach(data['value'], val => {
          this.serachTitleList.push(val.Title);
        });
      }
    });
  }

  /* Returns popular search term */
  popuplarSearchTerm() {
    this.popuplarSearchList = [];
    const query = '?$orderby=count desc&$top=3';
    this.webService.getdata('searchList', query).subscribe(data => {
      this.popuplarSearchList = data['value'];
    });
  }

  /* For showing and hiding tabs in mobile view */
  showOnMob(tabName: string) {
    this.selectedMobTab = this.selectedMobTab == tabName ? '' : tabName;
  }

  getRecentlyVisitedPageDetails() {
    const listname = 'UserBasedContent';
    const queryParams = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    try {
      this.webService.getdata(listname, queryParams).subscribe(data => {
        if (data['value'].length > 0) {
          this.recentlyVisitedData['chunkData'] = _.chunk(JSON.parse(data['value'][0]['RecentlyVisitedPage']), 4);
          this.recentlyVisitedData['rawData'] = JSON.parse(data['value'][0]['RecentlyVisitedPage']);
        }
      });
    } catch (error) {
      console.log('Error Message ', error);
    }
  }

  /* Redirect to respective tenets page on dropdown change mobile view */
  navigateOnChange(url) {
    this.route.navigateByUrl(url);
  }

  /* Convert string to Object and return as Array of Object */
  parseData(value: any) {
    return JSON.parse(value);
  }

  /* Converts tje first character of the string to upper case */
  startCaseFormat(text: string) {
    return _.startCase(text);
  }
}

/* Added for hiding Header search field in Dashboard component */
@Directive({ selector: '[appBodyDashboard]' })
export class HeaderDashboardDirective implements OnDestroy, AfterViewInit {
  ngAfterViewInit() {
    document.querySelector('body').classList.add('dashBoardPage');
  }
  ngOnDestroy(): void {
    document.querySelector('body').classList.remove('dashBoardPage');
  }
}
