import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { WebService } from './web.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private webService: WebService) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    this.webService.handleWindowCallback();
    /* Check the session Expired and set the exact url */
    const reqURI = state.url.includes('#') ? sessionStorage.getItem('redirectUri') : state.url;
    sessionStorage.setItem('redirectUri', reqURI);

    /* Return true when the user is authenticated */
    if (this.webService.authenticate) {
      return true;
    }

    this.webService.login();
    return false;
  }
}
