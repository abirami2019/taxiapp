import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  filterMenu = [];
  defaultSmartColumnName = [
    { columnName: 'column1', noContent: true },
    { columnName: 'column2', noContent: true },
    { columnName: 'column3', noContent: true },
    { columnName: 'column4', noContent: true },
    { columnName: 'column5', noContent: true },
    { columnName: 'column6', noContent: true },
    { columnName: 'column7', noContent: true },
    { columnName: 'column8', noContent: true },
    { columnName: 'column9', noContent: true },
    { columnName: 'column10', noContent: true },
    { columnName: 'column11', noContent: true },
    { columnName: 'column12', noContent: true }
  ];

  constructor(private route: Router) {}

  /**
   * Form the menu item in Tree structure
   * @param arr Array
   */
  transformToTree(arr: Array<Object>) {
    const nodes = {};
    return arr.filter(function(obj) {
      const id = obj['id'],
        parentId = obj['parent'];
      nodes[id] = _.defaults(obj, nodes[id], { children: [] });
      // tslint:disable-next-line:no-unused-expression
      parentId && (nodes[parentId] = nodes[parentId] || { children: [] })['children'].push(obj);
      return !parentId;
    });
  }

  /**
   * Create Menu item with listed structure
   * @param data array
   */
  createMenu(data) {
    const menu = [];
    Object.keys(data['value']).forEach((value, index) => {
      menu.push({
        id: data['value'][index]['ID'],
        link: data['value'][index]['menu_link'],
        title: data['value'][index]['Title'],
        parent: data['value'][index]['menu_parent'],
        order: data['value'][index]['menu_order'],
        page: data['value'][index]['has_page'],
        isEnabled: data['value'][index]['isEnabled'],
        checked: false
      });
    });
    return this.transformToTree(_.orderBy(menu, ['order']));
  }

  /**
   * Returns the given Menu items list
   * @param arr Array
   * @param menuItem String
   */
  getTreelist(arr, menuItem: string) {
    const menuItems: any = this.createMenu(arr);
    return menuItems.filter(function(item) {
      return item.title == menuItem;
    });
  }

  /**
   * Sub childrens are return in tree format
   * @param obj Object
   */
  traverse(obj) {
    for (const k in obj) {
      if (obj[k] && typeof obj[k] === 'object') {
        const omited = _.omit(obj[k], 'children');
        if (omited['id'] !== undefined) {
          this.filterMenu.push(omited);
        }
        this.traverse(obj[k]);
      }
    }
    return this.filterMenu;
  }

  /* To get all the Page related properites*/
  getPager(totalItems: number, currentPage: number = 1, itemsToShow: number) {
    // calculate total pages
    const totalPages = Math.ceil(totalItems / itemsToShow);
    // ensure current page isn't out of range
    if (currentPage < 1) {
      currentPage = 1;
    } else if (totalPages > 0 && currentPage > totalPages) {
      currentPage = totalPages;
    }
    let startPage: number, endPage: number;
    if (totalPages <= 5) {
      // less than 5 total pages so show all
      startPage = 1;
      endPage = totalPages;
      // } else {
      //   // more than 10 total pages so calculate start and end pages
      //   if (currentPage <= 5) {
      //     startPage = 1;
      //     endPage = 5;
      //   } else if (currentPage + 4 >= totalPages) {
      //     startPage = totalPages - 4;
      //     endPage = totalPages;
      //   } else {
      //     startPage = currentPage - 5;
      //     endPage = currentPage + 4;
      //   }
      // }
    } else {
      // more than 5 total pages so calculate start and end pages
      if (currentPage <= 5) {
        startPage = 1;
        endPage = 5;
      } else if (currentPage + 1 >= totalPages) {
        startPage = totalPages - 4;
        endPage = totalPages;
      } else {
        startPage = currentPage - 2;
        endPage = currentPage + 2;
      }
    }
    // calculate start and end item indexes
    let startIndex = 0;
    let endIndex = 0;
    if (totalPages == 0) {
      startIndex = -1;
      endIndex = -1;
    } else {
      startIndex = (currentPage - 1) * itemsToShow;
      endIndex = Math.min(startIndex + (itemsToShow - 1), totalItems - 1);
    }
    // create an array of pages to ng-repeat in the pager control
    const pages = Array.from(Array(endPage + 1 - startPage).keys()).map(i => startPage + i);
    // return object with all pager properties required by the view
    return {
      totalItems: totalItems,
      currentPage: currentPage,
      pageSize: itemsToShow,
      totalPages: totalPages,
      startPage: startPage,
      endPage: endPage,
      startIndex: startIndex,
      endIndex: endIndex,
      pages: pages
    };
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  customNavigation(pageURL, menuName) {
    if (menuName) {
      this.route.navigateByUrl(pageURL + '?tab=' + menuName);
    }
  }
}
