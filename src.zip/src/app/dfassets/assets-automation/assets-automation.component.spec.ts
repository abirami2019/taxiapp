import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsAutomationComponent } from './assets-automation.component';

describe('AssetsAutomationComponent', () => {
  let component: AssetsAutomationComponent;
  let fixture: ComponentFixture<AssetsAutomationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetsAutomationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetsAutomationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
