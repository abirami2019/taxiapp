import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KnowledgeAssetComponent } from './knowledge-asset.component';

describe('KnowledgeAssetComponent', () => {
  let component: KnowledgeAssetComponent;
  let fixture: ComponentFixture<KnowledgeAssetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KnowledgeAssetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KnowledgeAssetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
