import { Component, OnInit, HostListener } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { WebService } from '../services/web.service';
import { SharedService } from '../services/shared.service';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import * as _ from 'lodash';

@Component({
  selector: 'app-resourcecenter',
  templateUrl: './resource-center.component.html',
  styleUrls: ['./resource-center.component.css']
})
export class ResourceCenterComponent implements OnInit {
  filterArray = [
    { name: 'All', selected: true, value: 'All' },
    { name: 'o2c', selected: false, value: 'Order to Cash (O2C)' },
    { name: 'p2p', selected: false, value: 'Procure to Pay (P2P)' },
    { name: 'r2r', selected: false, value: 'Record to Report (R2R)' }
  ];

  inputColumns = [
    { columnName: 'Title', text: 'Asset Name' },
    { columnName: 'Description', text: 'Description' },
    { columnName: 'Benefits', text: 'Key Business Benefits' },
    { columnName: 'Implemented', text: 'Implemented in' },
    { columnName: 'owner_name', text: 'Asset Owner' }
  ];
  mainTabHeadings = ['All', 'BFS', 'Insurance', 'Healthcare', 'LS', 'CMT', 'RHCG', 'MLEU', 'Enterprise_Service', 'IPA'];
  displayedColumns: string[] = ['asset_name', 'description', 'benefits', 'Implemented', 'owner_name'];
  selectedMainTab = this.mainTabHeadings[0];
  selectedSection: string;
  tableContent = new Array();
  makeDefaultPage = false;
  itemId: string;
  listItem: Array<Object>;
  documnentTitle: string;
  visibleItem: string;
  innerWidth: any;
  newsOrder = 'desc';
  pager: any = {};
  pageOptions = [5, 10, 20];
  itemsToShow = this.pageOptions[0];
  pagedItems: any[];
  filteredItems: any[];
  allItemsLength: number;
  currentPageIndex: number;
  filterTitle: string;
  baseUrl = environment.config.spUrl + environment.config.spSiteCollection;
  sortingOrder: any;
  fitlerSearchEnabled = true;
  currentPageName: string;
  parentPageName: string;

  constructor(private titleService: Title, private webService: WebService, private route: Router, private shareService: SharedService) {}

  ngOnInit() {
    const urlQueryString = this.route.url.split('/');
    this.selectedSection = _.startCase(urlQueryString[2]);
    this.titleService.setTitle(this.selectedSection);
    this.parentPageName = urlQueryString[1];
    this.currentPageName = urlQueryString[2];
    this.getOnloadData();
    this.innerWidth = window.innerWidth;
    switch (this.selectedSection) {
      case 'News Letter':
        this.getdataFromSP(['latestIssue', 'previousIssuesList']);
        break;
      case 'Do Templates':
        this.getdataFromSP(['DFTemplateMain', 'DFTemplateEntry']);
        break;
      case 'Do Decks':
        this.getdataFromSP(['DFDeckMain', 'DFDeckSolutionEntry', 'DFDeckPresentationEntry']);
        break;
      case 'Assets Catalogue':
        this.getSummaryList(this.selectedMainTab);
        this.getdataFromSP(['asset_catalogue_download_path']);
        break;
      default:
        break;
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
  }

  /* To get DO Templates content from SharePoint */
  getdataFromSP(tabName: any) {
    this.listItem = [];
    tabName.forEach((val: any, key: any) => {
      const listname = 'RC_Assests';
      const queryParams = '?$filter=Title eq \'' + tabName[key] + '\'';
      this.webService.getdata(listname, queryParams).subscribe(data => {
        if (tabName[key] == 'previousIssuesList') {
          this.listItem[tabName[key]] = _.groupBy(data['value'], 'issueYear');
          this.sortBasedcategory();
        } else {
          this.listItem[tabName[key]] = data['value'];
        }
      });
    });
  }

  /* Newsletter page sorting */
  sortBasedcategory() {
    if (this.newsOrder == 'desc') {
      const a = Object.keys(this.listItem['previousIssuesList']);
      const obj = [];
      _.forEach(a.reverse(), (val, key) => {
        obj.push(this.listItem['previousIssuesList'][val]);
      });
      this.listItem['previousIssuesList'] = obj;
    } else {
      const a = Object.keys(this.listItem['previousIssuesList']);
      const obj = [];
      _.forEach(a.reverse(), (val, key) => {
        obj.push(this.listItem['previousIssuesList'][val]);
      });
      this.listItem['previousIssuesList'] = obj;
    }
  }

  /* Get data from SharePoint List to display in summary page */
  getSummaryList(tabName) {
    if (this.tableContent != null && (this.tableContent[tabName] == undefined || this.tableContent.length < 0)) {
      const listname = 'DetailPage';
      const queryParams = '?$filter=solutionDepends eq \'Automation\' or solutionDepends eq \'Analytics\'&$top=500';
      _.forEach(this.mainTabHeadings, val => {
        this.tableContent[val] = [];
      });
      this.webService.getdata(listname, queryParams).subscribe(data => {
        _.forEach(data['value'], val => {
          switch (val.assetDepends) {
            case 'mortgage-operations':
            case 'kyc':
            case 'data-integrity-control':
              this.tableContent['BFS'].push(val);
              break;
            case 'la-ops':
            case 'pc-ops':
              this.tableContent['Insurance'].push(val);
              break;
            case 'revenue-cycle-management':
            case 'claims-processing':
            case 'membership-services':
            case 'provider-services':
            case 'clinical-services':
              this.tableContent['Healthcare'].push(val);
              break;
            case 'pharmacovigilance':
            case 'complaints-management':
            case 'clinical-data-management':
              this.tableContent['LS'].push(val);
              break;
            case 'user-generated-content':
            case 'digital-marketing':
            case 'location-based-services':
            case 'brand-generated-content':
              this.tableContent['CMT'].push(val);
              break;
            case 'retail-ops':
              this.tableContent['RHCG'].push(val);
              break;
            case 'procure-to-pay':
            case 'order-to-cash':
            case 'next-gen-cc':
              this.tableContent['Enterprise_Service'].push(val);
              break;
            case 'enterprise-automation':
            case 'operational-analytics':
              this.tableContent['IPA'].push(val);
              break;
            default:
              break;
          }
          this.tableContent['All'].push(val);
        });
        if (tabName) {
          this.allItemsLength = this.tableContent[tabName].length;
        }
        this.setPage(1);
      });
    } else {
      this.fitlerSearchEnabled = true;
      this.setPage(1);
      this.filterTitle = '';
      return;
    }
  }

  /* Set active for choosed Accordian in mobile view */
  toggleContent(itemName: string) {
    this.visibleItem = this.visibleItem != itemName ? itemName : undefined;
  }

  /* check the current page has bookmarked or default page */
  getOnloadData() {
    const getDefaultPageQuery = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    this.webService.getdata('UserBasedContent', getDefaultPageQuery).subscribe(res => {
      if (res['value'].length > 0) {
        this.itemId = res['value'][0]['ID'];
        if (res['value'][0]['DefaultPageUrl'] == this.route.url) {
          this.makeDefaultPage = true;
        }
      }
    });
  }

  /* Set Defaultlanding page when checkbox clicked */
  setDefaultLandingPage() {
    let pageUrl;
    if (!this.makeDefaultPage) {
      pageUrl = this.route.url;
    } else {
      pageUrl = '';
    }
    const body = {
      __metadata: { type: 'SP.Data.UserBasedContentListItem' },
      Title: this.webService.getUserInfo().profile.name,
      UserId: this.webService.getUserName,
      DefaultPageUrl: pageUrl
    };

    if (this.itemId) {
      this.webService.updateSPList('UserBasedContent', this.itemId, body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          this.getOnloadData();
        }
      );
    } else {
      this.webService.postDataToSP('UserBasedContent', body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          this.getOnloadData();
        }
      );
    }
  }
  /* Convert string to Object and return as Array of Object */
  parseData(value: any) {
    return [JSON.parse(value)];
  }

  /* To get the checked item and status of the filter item from the UI */
  getCheckedItem(checkedItem: any, status: any) {
    if (checkedItem == 'All' && status) {
      _.forEach(this.filterArray, value => {
        if (value.name == 'All') {
          return;
        }
        value.selected = !status;
      });
    } else {
      _.forEach(this.filterArray, function(value) {
        if (value.name == 'All') {
          value.selected = false;
        }
      });
    }
  }

  /* Get search text from form */
  filterText(s) {
    if (s == '') {
      this.fitlerSearchEnabled = true;
      this.setPage(this.pager.currentPage);
      return;
    }
    this.fitlerSearchEnabled = false;
    this.filteredItems = [];
    _.forEach(this.tableContent[this.selectedMainTab], val => {
      if (_.lowerCase(val.shortName).includes(_.lowerCase(s))) {
        this.filteredItems.push(val);
      }
    });
    this.setPage(1);
  }

  /* To get the Page Items to be show based on the user selection of dropdown */
  setPage(page: number) {
    const availableData = this.fitlerSearchEnabled ? this.tableContent[this.selectedMainTab] : this.filteredItems;
    this.allItemsLength = availableData.length;
    this.pager = this.shareService.getPager(availableData.length, page, this.itemsToShow);
    this.pagedItems = availableData.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }

  /* Dropdonw OnChange event to show the number of items in a page */
  selectPageChangeHandler(event: any) {
    const availableData = this.fitlerSearchEnabled ? this.tableContent[this.selectedMainTab] : this.filteredItems;
    this.pager = this.shareService.getPager(availableData.length, 1, this.itemsToShow);
    this.pagedItems = availableData.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }

  /* Sort based title */
  sortSummary(val: any) {
    if (val == undefined) {
      val = 'desc';
    }
    this.sortingOrder = val == 'desc' ? 'asc' : 'desc';
    this.pagedItems = _.orderBy(this.pagedItems, ['Title'], this.sortingOrder);
  }

  /* Download report in asset catalogue page */
  downloadDocument(data) {
    window.open(this.baseUrl + data);
  }

  scrollTop() {
    this.shareService.scrollToTop();
  }
}
