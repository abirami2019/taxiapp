import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appPopupmodal]'
})
export class PopupmodalDirective {

  constructor() { }
  @HostListener('click') modalOpen() {
    document.getElementById('appPopupmodal').classList.toggle('d-block');
  }
}
