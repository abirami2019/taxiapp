import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { AuthGuard } from './services/auth.guard';
import { AboutdfComponent } from './aboutdf/aboutdf.component';
import { DigitalfinanceComponent } from './solutions/enterpriseservices/digitalfinance/digitalfinance.component';
import { AssetsAnalyticsComponent } from './dfassets/assets-analytics/assets-analytics.component';
import { AssetsAutomationComponent } from './dfassets/assets-automation/assets-automation.component';
import { ResourceCenterComponent } from './resourceCenter/resource-center.component';
import { KnowledgeAssetComponent } from './dfassets/knowledge-asset/knowledge-asset.component';
import { PharmacovigilanceComponent } from './solutions/ls/pharmacovigilance/pharmacovigilance.component';
import { DigitalMarketingComponent } from './solutions/cmt/DigitalMarketing/digitalmarketing.component';
import { SearchComponent } from './search/search.component';
import { KycComponent } from './solutions/bfs/kyc/kyc.component';
import { UsergeneratedcontentComponent } from './solutions/cmt/usergeneratedcontent/usergeneratedcontent.component';
import { RevenuecyclemgmtComponent } from './solutions/healthcare/revenuecyclemgmt/revenuecyclemgmt.component';
import { MortgageoperationsComponent } from './solutions/bfs/mortgageoperations/mortgageoperations.component';
import { LAOpsComponent } from './solutions/insurance/la-ops/la-ops.component';
import { PCOpsComponent } from './solutions/insurance/pc-ops/pc-ops.component';
import { LocationBasedServicesComponent } from './solutions/cmt/location-based-services/location-based-services.component';
import { NextGenSalesCCComponent } from './solutions/enterpriseservices/next-gen-sales-cc/next-gen-sales-cc.component';
import { HcpayeropsComponent } from './solutions/healthcare/hcpayerops/hcpayerops.component';
import { RetailopsComponent } from './solutions/rhcg/retailops/retailops.component';
import { ManufacturingopsComponent } from './solutions/mleu/manufacturingops/manufacturingops.component';
import { DataintegritycontrolComponent } from './solutions/bfs/dataintegritycontrol/dataintegritycontrol.component';
import { ComplaintsmanagementComponent } from './solutions/ls/complaintsmanagement/complaintsmanagement.component';
import { BrokeragefeesandbillingComponent } from './solutions/bfs/brokeragefeesandbilling/brokeragefeesandbilling.component';
import { AssetwealthmanagementComponent } from './solutions/bfs/assetwealthmanagement/assetwealthmanagement.component';
import { RetailbankingComponent } from './solutions/bfs/retailbanking/retailbanking.component';
import { EnterpriseautomationComponent } from './solutions/ipa/enterpriseautomation/enterpriseautomation.component';
import { OperationalanalyticsComponent } from './solutions/ipa/operationalanalytics/operationalanalytics.component';
import { ProcessConsultingComponent } from './solutions/enterpriseservices/process-consulting/process-consulting.component';
import { BrandGeneratedContentComponent } from './solutions/cmt/brand-generated-content/brand-generated-content.component';
import { DigitalCustomerExperienceComponent } from './solutions/cmt/digital-customer-experience/digital-customer-experience.component';
import { OrderToCashComponent } from './solutions/enterpriseservices/digitalfinance/order-to-cash/order-to-cash.component';
import { RecordToReportComponent } from './solutions/enterpriseservices/digitalfinance/record-to-report/record-to-report.component';
import { ClinicalDataManagementComponent } from './solutions/ls/clinical-data-management/clinical-data-management.component';
import { DummyComponent } from './solutions/bfs/dummy/dummy.component';
const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'aboutdf', component: AboutdfComponent, canActivate: [AuthGuard] },
  { path: 'search', component: SearchComponent, canActivate: [AuthGuard] },
  {
    path: 'dfsolutions',
    canActivate: [AuthGuard],
    children: [
      {
        path: 'bfs',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'kyc',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: KycComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: KycComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'dummy',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: DummyComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: DummyComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'mortgage-operations',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: MortgageoperationsComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: MortgageoperationsComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'data-integrity-control',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: DataintegritycontrolComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: DataintegritycontrolComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'brokerage-fees-billing',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: BrokeragefeesandbillingComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'asset-wealth-mgmt',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: AssetwealthmanagementComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'retail-banking',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: RetailbankingComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: RetailbankingComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      },
      {
        path: 'insurance',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'la-ops',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: LAOpsComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: LAOpsComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'pc-ops',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: PCOpsComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: PCOpsComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      },
      {
        path: 'healthcare',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'revenue-cycle-management',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: RevenuecyclemgmtComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'hc-payer-ops',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'claims-processing',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'key-tenets', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'process-reimagine', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'human-centric-design', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'smart-analytics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'new-age-metrics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'agile-operating-model', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'intelligent-automation', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'digital-ready-talent', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'shared-culture', component: HcpayeropsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'membership-services',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'key-tenets', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'process-reimagine', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'human-centric-design', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'smart-analytics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'new-age-metrics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'agile-operating-model', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'intelligent-automation', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'digital-ready-talent', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'shared-culture', component: HcpayeropsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'provider-services',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'key-tenets', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'process-reimagine', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'human-centric-design', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'smart-analytics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'new-age-metrics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'agile-operating-model', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'intelligent-automation', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'digital-ready-talent', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'shared-culture', component: HcpayeropsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'clinical-services',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'key-tenets', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'process-reimagine', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'human-centric-design', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'smart-analytics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'new-age-metrics', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'agile-operating-model', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'intelligent-automation', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'digital-ready-talent', component: HcpayeropsComponent, canActivate: [AuthGuard] },
                  { path: 'shared-culture', component: HcpayeropsComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          }
        ]
      },
      {
        path: 'ls',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'pharmacovigilance',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: PharmacovigilanceComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'complaints-management',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: ComplaintsmanagementComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'clinical-data-management',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: ClinicalDataManagementComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      },
      {
        path: 'cmt',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'user-generated-content',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: UsergeneratedcontentComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'brand-generated-content',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: BrandGeneratedContentComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'location-based-services',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: LocationBasedServicesComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: LocationBasedServicesComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'digital-marketing',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: DigitalMarketingComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: DigitalMarketingComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'digital-customer-experience',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: DigitalCustomerExperienceComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      },
      {
        path: 'rhcg',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'retail-ops',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: RetailopsComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: RetailopsComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      },
      {
        path: 'mleu',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'manufacturing-ops',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: ManufacturingopsComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: PharmacovigilanceComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: PharmacovigilanceComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      },
      {
        path: 'enterprise-service',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'digital-finance',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'order-to-cash',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'key-tenets', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'process-reimagine', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'human-centric-design', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'smart-analytics', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'new-age-metrics', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'agile-operating-model', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'intelligent-automation', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'digital-ready-talent', component: OrderToCashComponent, canActivate: [AuthGuard] },
                  { path: 'shared-culture', component: OrderToCashComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'procure-to-pay',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'key-tenets', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'process-reimagine', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'human-centric-design', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'smart-analytics', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'new-age-metrics', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'agile-operating-model', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'intelligent-automation', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'digital-ready-talent', component: DigitalfinanceComponent, canActivate: [AuthGuard] },
                  { path: 'shared-culture', component: DigitalfinanceComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'record-to-report',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'key-tenets', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'process-reimagine', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'human-centric-design', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'smart-analytics', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'new-age-metrics', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'agile-operating-model', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'intelligent-automation', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'digital-ready-talent', component: RecordToReportComponent, canActivate: [AuthGuard] },
                  { path: 'shared-culture', component: RecordToReportComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'next-gen-cc',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: NextGenSalesCCComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: NextGenSalesCCComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'process-consulting',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: ProcessConsultingComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: ProcessConsultingComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      },
      {
        path: 'intelligent-process-automation',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'enterprise-automation',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: EnterpriseautomationComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: EnterpriseautomationComponent, canActivate: [AuthGuard] }
            ]
          },
          {
            path: 'operational-analytics',
            canActivate: [AuthGuard],
            children: [
              { path: '', redirectTo: 'key-tenets', pathMatch: 'full', canActivate: [AuthGuard] },
              { path: 'key-tenets', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'process-reimagine', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'human-centric-design', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'smart-analytics', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'new-age-metrics', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'agile-operating-model', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'intelligent-automation', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'digital-ready-talent', component: OperationalanalyticsComponent, canActivate: [AuthGuard] },
              { path: 'shared-culture', component: OperationalanalyticsComponent, canActivate: [AuthGuard] }
            ]
          }
        ]
      }
    ]
  },
  {
    path: 'dfassets',
    canActivate: [AuthGuard],
    children: [
      {
        path: 'analytics',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'all-assets',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'analytics',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'bfs',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'casestudy',
                children: [
                  { path: '', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'rpa-analytics-solution', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'journal-posting', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              },

              {
                path: 'kyc',
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'kyc-eRadar', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'kyc-capacity-model', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'dummy',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'element1', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  ]
              },
              {
                path: 'mortgage-operations',
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'mg-automatic-mis', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
              path: 'dummy',
              children: [
                { path: 'element1', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
              ]
            }
            ]
          },
          {
            path: 'insurance',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'casestudy',
                children: [
                  { path: '', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'ibm-watson-smart-email', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'suspense-reduction', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'ls',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'pharmacovigilance',
                canActivate: [AuthGuard],
                children: [
                  {
                    path: '',
                    redirectTo: 'summary',
                    pathMatch: 'full'
                  },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'regulatory-latecase-compliance-report', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'cmt',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'location-based-services',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-aggregate-reports-ugc-optimizer', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-transaction-intake-queue-valet', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-quality-review-proto-reader', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-aggregate-reports-datastudio', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-detection-transaction-validity-calibre', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'digital-marketing',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'dm-csat-prediction-tool', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'dm-dynamic-volume-forecasting', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'casestudy',
                children: [
                  { path: 'crystal-gazer', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'gdo-value-delivery', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'rhcg',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'retail-ops',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-chronic-analyzer', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'enterprise-service',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'digital-finance',
                canActivate: [AuthGuard],
                children: [
                  {
                    path: 'procure-to-pay',
                    canActivate: [AuthGuard],
                    children: [
                      {
                        path: '',
                        redirectTo: 'summary',
                        pathMatch: 'full'
                      },
                      { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                      { path: 'spendwiz', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                      { path: 'quality-audit-prescriptive-analytics', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                      { path: 'p2p-dashboard', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                    ]
                  },
                  {
                    path: 'order-to-cash',
                    canActivate: [AuthGuard],
                    children: [
                      {
                        path: '',
                        redirectTo: 'summary',
                        pathMatch: 'full'
                      },
                      { path: 'summary', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-investigation-invoice', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        path: 'automation-solutions',
        canActivate: [AuthGuard],
        children: [
          {
            path: 'all-assets',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'automation',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'bfs',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'kyc',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pre-kyc-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'kyc-document-collection', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'background-checks-robo', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'sanctions-vulnerable-business-activity', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              
              {
                path: 'dummy',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pre-kyc-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  ]
              },
              {
                path: 'mortgage-operations',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-automated-consolidation-follow-up-tracker', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-automatic-email-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-automatic-generation-report', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-automatic-consolidation-generation-report', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-foreclosure-ipa', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-loss-mitigation-ipa', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-automated-qc-feedback-mechanism', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-update-management-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-denial-letters-generation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-assignment-claims-notes-maker', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-fnma-claims-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'mg-fnma-claims-automation-tax-consolidation', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'data-integrity-control',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dic-reporting-analytics', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'insurance',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'la-ops',
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'la-ctm-outstanding-trades-resolution', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'la-overdue-payments', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'la-termination', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'la-archiving-documents', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'la-task-creation-crm', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'pc-ops',
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-pt-search-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-pt-nt-intake-non-ru-filter', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-concentra-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-payor-verification', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-epq-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-cash-app-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-dme-hh-triaging-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-ru2-end2end-improvement', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-data-collection', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-policy-cancellations-by-phone-paper', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-nq-auto-renewals', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-insured-request-for-cancellation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-desktop-support', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-aarp-new-producer-authorization', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-agency-contract-maintenance', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-5plus-direct-billing-manual-entry', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-agency-contract-termination', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-security-admin-infrastructure', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-certificate-insurance-pc-conversion', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-agency-non-contract-maintenance', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-appointment-termination', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-producer-agency-establish-appointment', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-agency-licensing', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-location-changes', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-new-business-marine-prep', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-new-business-renewal-prep', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-vehicle-changes', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-closeout-policy-center', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-statement-audit-paygo', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-wc-manual-physical-telephone', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-ccrm', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-billing-dnoc', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-claims-coding', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-motor-claims-payout', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'pc-property-claims-invoice-payment', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'healthcare',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'casestudy',
                children: [
                  { path: '', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'anthem-automated-text-letter', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'modmed-eb-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'revenue-cycle-management',
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-paper-resolve-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-pp-era-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-eligibility-benefits-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-claim-status-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-appeals-rpa-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-notes-posting-rpa-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-collections-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-pp-unapplied-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  {
                    path: 'rcm-claimStatus-notePosting-tpa-rpa-implementation',
                    component: AssetsAutomationComponent,
                    canActivate: [AuthGuard]
                  },
                  { path: 'rcm-claim-status-nammnet-rpa-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-claim-status-tps-rpa-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-cass-error-rpa-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-charge-entry-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-dof-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-prohance-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-optum-download', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rcm-appeals-package-uploader', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'hc-payer-ops',
                canActivate: [AuthGuard],
                children: [
                  {
                    path: 'claims-processing',
                    canActivate: [AuthGuard],
                    children: [
                      { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                      { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-shermanator', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automated-text', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-022', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-051', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-774', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automated-letter', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-dcn-tagging', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-edit-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-correspondence', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-atom', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-gladiator', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-009', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-569', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-032', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-648', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-423', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-365', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cp-automation-edit-493', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                    ]
                  },
                  {
                    path: 'membership-services',
                    canActivate: [AuthGuard],
                    children: [
                      { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                      { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ms-prior-coverage-maintenance', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ms-nv-state-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ms-upc-refunds', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                    ]
                  },
                  {
                    path: 'provider-services',
                    canActivate: [AuthGuard],
                    children: [
                      { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                      { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-term-date-calculator', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-caqh-auto-download-upload', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-metric-report-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-one-note-delimiter-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-print-merge-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-psv-tracker', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-automatic-untracked-email-scrub-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-automating-tracked-emails-faxes', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-cred-re-credentialing', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ps-sanction-termination', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                    ]
                  },
                  {
                    path: 'clinical-services',
                    canActivate: [AuthGuard],
                    children: [
                      { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                      { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cs-notes-template', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'cs-error-classifier-medicare-advantage', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                    ]
                  }
                ]
              }
            ]
          },

          {
            path: 'ls',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'casestudy',
                children: [
                  { path: '', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'takeda-ev-macro-tool', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] },
                  { path: 'novartis-lp-sr-automation', component: AssetsAnalyticsComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'pharmacovigilance',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'e2b-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ev-ca-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'duplicate-search-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dof-prohance', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'non-e2b-structured-initial-cases', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ae-source-affiliate', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'case-initiation-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'cjn-entry-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'case-finalization-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rxlogix', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rxl-reports', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rxl-signal', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'complaints-management',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-smart-allocator', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-decision-tree-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-auto-narrative-case-review', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-case-review-highlighter', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-auto-narrative-investigator', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'clinical-data-management',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-query-management', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-auto-clean-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-lsh-query-management', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-set-up-smart', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ls-automation-missing-pages-report', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'cmt',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'user-generated-content',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ugc-keyword-highlighter', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ugc-hot-key', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ugc-sme-support-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ugc-screen-capture-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ugc-policy-management-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ugc-associate-365', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'ugc-time-tracking-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'location-based-services',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-duplicate-search-magnify', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-quality-review-elixir', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-quality-review-fms', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-aggregate-reports-tops-optimizer', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-aggregate-reports-terra', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-full-transaction-review-clueboard', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-workflow-management-wap', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-aggregate-reports-ugc-optimizer', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'lbs-detection-transaction-validity-calibre', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'digital-marketing',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-feedback-management-system', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-error-catcher', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-update-management-system', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-automation-knowledgeTest-generator', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-real-time-dashboard', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-api-based-application-deep-learning', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-conversational-bots', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-auto-extraction-machineLearning', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-ad-campaign-performance-scripts', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-ad-campaign-automated-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-calibre', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'dm-customer-care-izip', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              },
              {
                path: 'brand-generated-content',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'bgc-ppt-remediation-tools-nonmath', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'bgc-ppt-remediation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'bgc-validation-tool-pxe', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'bgc-ppt-remediation-tool-math', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'bgc-conley-readiness-Index-report-generation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'bgc-epub-conversion-process', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'rhcg',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'retail-ops',
                canActivate: [AuthGuard],
                children: [
                  { path: '', redirectTo: 'summary', pathMatch: 'full', canActivate: [AuthGuard] },
                  { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-alert-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-pos-rebuild', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-image-validation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-3p-product-matching', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-vendor-ticket-integration', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-cfs-job-allocation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-self-service-portal', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                  { path: 'rhcg-quality-monitoring', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                ]
              }
            ]
          },
          {
            path: 'enterprise-service',
            canActivate: [AuthGuard],
            children: [
              {
                path: 'digital-finance',
                canActivate: [AuthGuard],
                children: [
                  {
                    path: 'procure-to-pay',
                    canActivate: [AuthGuard],
                    children: [
                      {
                        path: '',
                        redirectTo: 'summary',
                        pathMatch: 'full'
                      },
                      { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'xtracta', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'grip_for_3way_match', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'bot-auto-matches-missing-grn', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'bot-reconciles-statement', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'idcs-implementation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'vendor-portal-enrollment', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'e-processing-for-indexing', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'barricade-edi', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'jira-service-desk', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ariba', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'coupa', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'servicenow', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'tradeshift', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'vat-validation-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'ap-exception-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'duplicate-audit-tool', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'payment-posting-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'dof-ilead', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'catalyst', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                    ]
                  },
                  {
                    path: 'order-to-cash',
                    canActivate: [AuthGuard],
                    children: [
                      {
                        path: '',
                        redirectTo: 'summary',
                        pathMatch: 'full'
                      },
                      { path: 'summary', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-collection-optimizer', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-sales-order', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-auto-cash-posting', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-idoc-orders-automation', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-on-account-cycle-time-reduction', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-order-registration', component: AssetsAutomationComponent, canActivate: [AuthGuard] },
                      { path: 'o2c-ar-invoicing-bot', component: AssetsAutomationComponent, canActivate: [AuthGuard] }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        path: 'knowledge-assets',
        canActivate: [AuthGuard],
        children: [
          { path: '', component: KnowledgeAssetComponent, canActivate: [AuthGuard] },
          { path: 'customer-journey-maps', component: KnowledgeAssetComponent, canActivate: [AuthGuard] },
          { path: 'process-flows', component: KnowledgeAssetComponent, canActivate: [AuthGuard] }
        ]
      }
    ]
  },
  {
    path: 'resource-center',
    canActivate: [AuthGuard],
    children: [
      { path: 'assets-catalogue', component: ResourceCenterComponent, canActivate: [AuthGuard] },
      { path: 'do-decks', component: ResourceCenterComponent, canActivate: [AuthGuard] },
      { path: 'do-templates', component: ResourceCenterComponent, canActivate: [AuthGuard] },
      { path: 'news-letter', component: ResourceCenterComponent, canActivate: [AuthGuard] }
    ]
  },
  { path: '**', component: NotFoundComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
