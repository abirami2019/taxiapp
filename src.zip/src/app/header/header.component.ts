import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { WebService } from '../services/web.service';
import { SharedService } from '../services/shared.service';
import { Directive, HostListener } from '@angular/core';
import * as _ from 'lodash';
import { environment } from '../../environments/environment';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  isSelectAll = false;
  innerWidth: number;
  hideSecondLvlMnu = true;
  favourites: any;
  selectedFavOption: string;
  popuplarSearchList: Array<Object>;
  toggleMenuItems = [{ title: '', selected: false }, { title: '', selected: false }, { title: '', selected: false }];

  isFavEnabled = new Array();
  myFavAssets: any;
  myFavSolutions: any;
  menuItems = [];
  profileName: any;
  hideSearchModal = false;
  serachTitleList = [];
  baseUrl = environment.config.spUrl + environment.config.spSiteCollection;
  profileImage: string;
  profileImage1: string;
  currentTime: any;
  // showNoContent = false;
  filteredData: Array<string>;
  headerSearch = new FormGroup({
    headerSearchInput: new FormControl('', [Validators.required, Validators.minLength(4)])
  });

  constructor(private webService: WebService, private shareService: SharedService, private route: Router, private datePipe: DatePipe) {}

  ngOnInit() {
    if (this.webService.authenticate) {
      this.profileName = this.webService.getUserInfo().profile['family_name'] + ', ' + this.webService.getUserInfo().profile['given_name'];
      this.profileImage = this.baseUrl + '_layouts/15/userphoto.aspx?size=L&username=' + this.webService.getUserInfo().userName;
      // this.profileImage1 = this.baseUrl + '_layouts/15/userphoto.aspx?size=L&username=714513@cognizant.com';
      this.getMenu();
    }
    this.innerWidth = window.innerWidth;
    this.popuplarSearchTerm();
    this.getAutoCompleteData();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
  }

  /* Display menu */
  getMenu() {
    const listname = 'NaviList';
    const queryParams = '?$top=200';
    this.webService.getdata(listname, queryParams).subscribe(data => {
      this.menuItems = this.shareService.createMenu(data);
      this.isFavEnabled['Assets'] = 0;
      this.isFavEnabled['Solutions'] = 0;
      const query = '?&$filter=UserID eq \'' + this.webService.getUserInfo().userName + '\'';
      this.webService.getdata('FavMenu', query).subscribe(
        response => {
          if (response['value'].length > 0) {
            this.isFavEnabled['uniqueId'] = response['value'][0]['ID'];
            this.isFavEnabled['Assets'] = response['value'][0]['IsFavAssetsEnabled'];
            this.isFavEnabled['Solutions'] = response['value'][0]['IsFavSolutionsEnabled'];
            this.myFavAssets = JSON.parse(response['value'][0]['FavAssetsItem']);
            this.myFavSolutions = JSON.parse(response['value'][0]['FavSolutionsItems']);

            /* To set favourites menu into this.menuItems array for Assets */
            if (this.isFavEnabled['Assets'] && this.myFavAssets.length > 0) {
              _.remove(this.myFavAssets[0].children, ['checked', false]);
              const myFav = _.forEach(this.myFavAssets[0].children, val => {
                if (val.checked) {
                  return _.remove(val.children, ['checked', false]);
                }
              });
              this.menuItems[2].children = myFav;
              this.myFavAssets = JSON.parse(response['value'][0]['FavAssetsItem']);
            }

            /* To set favourites menu into this.menuItems array for Solutions */
            if (this.isFavEnabled['Solutions'] && this.myFavSolutions.length > 0) {
              _.remove(this.myFavSolutions[0].children, ['checked', false]);
              const myFav = _.forEach(this.myFavSolutions[0].children, val => {
                if (val.checked) {
                  return _.remove(val.children, ['checked', false]);
                }
              });
              this.menuItems[1].children = myFav;
              this.myFavSolutions = JSON.parse(response['value'][0]['FavSolutionsItems']);
            }
          }
        },
        error => {
          console.log('error in Header component');
          console.log(error);
        }
      );
    });
  }

  /* Application Logout */
  logout() {
    sessionStorage.clear();
    this.webService.logout();
  }

  /* Search function in header */
  headerSearchFn(searchText) {
    if (searchText.headerSearchInput.length < 2) {
      return;
    }
    this.route.navigateByUrl('/search?t=' + searchText.headerSearchInput);
  }

  /* Return Sub navigation to select as favourites */
  getfavourites(menuOptions: any) {
    this.favourites = [];
    this.selectedFavOption = menuOptions;
    if (menuOptions == 'Assets' && this.isFavEnabled['Assets']) {
      this.favourites = this.myFavAssets;
      return;
    }
    if (menuOptions == 'Solutions' && this.isFavEnabled['Solutions']) {
      this.favourites = this.myFavSolutions;
      return;
    }

    const listname = 'NaviList';
    const queryParams = '?$top=200';
    this.webService.getdata(listname, queryParams).subscribe(res => {
      this.favourites = this.shareService.getTreelist(res, menuOptions);
    });
  }

  /* Selected favourites items */
  getSelectedValues(values) {
    const selectedVal = _.filter(values[0].children, ['checked', true]);
    if (selectedVal.length == 0) {
      return;
    }

    let myFavAsset = this.myFavAssets,
      myFavSolutions = this.myFavSolutions;
    let myFavAssetEnabled = this.isFavEnabled['Assets'],
      myFavSolutionsEnabled = this.isFavEnabled['Solutions'];
    if (this.selectedFavOption == 'Assets') {
      myFavAsset = values;
      myFavAssetEnabled = 1;
    }
    if (this.selectedFavOption == 'Solutions') {
      myFavSolutions = values;
      myFavSolutionsEnabled = 1;
    }
    const body = {
      __metadata: { type: 'SP.Data.FavMenuListItem' },
      Title: this.webService.getUserInfo().profile['name'],
      UserID: this.webService.getUserInfo().userName,
      IsFavAssetsEnabled: myFavAssetEnabled,
      IsFavSolutionsEnabled: myFavSolutionsEnabled,
      FavAssetsItem: JSON.stringify(myFavAsset),
      FavSolutionsItems: JSON.stringify(myFavSolutions)
    };
    if (this.isFavEnabled['uniqueId']) {
      this.webService.updateSPList('FavMenu', this.isFavEnabled['uniqueId'], body).subscribe(res => {
        this.enableOrDisableFav(this.selectedFavOption, 0);
      });
    } else {
      this.webService.postDataToSP('FavMenu', body).subscribe(res => {
        this.enableOrDisableFav(this.selectedFavOption, 0);
      });
    }
  }

  /* Enable or disable Favmenu based on the input */
  enableOrDisableFav(title, status) {
    this.isFavEnabled[title] = status ? 0 : 1;

    const body = {
      __metadata: { type: 'SP.Data.FavMenuListItem' },
      IsFavAssetsEnabled: this.isFavEnabled['Assets'],
      IsFavSolutionsEnabled: this.isFavEnabled['Solutions']
    };

    if (this.isFavEnabled['uniqueId']) {
      this.webService.updateSPList('FavMenu', this.isFavEnabled['uniqueId'], body).subscribe(res => {});
    }
    this.ngOnInit();
  }

  /* If Fav menu's Parent click its subordinate child also will get select or unselect */
  toggleChild(parent_id, status) {
    this.isSelectAll = false;
    _.forEach(this.favourites[0].children, v => {
      if (v.id == parent_id) {
        _.forEach(v.children, val => {
          val.checked = !status;
        });
      }
    });
  }

  /* If Fav menu's child is selected Parent also get selected automatically */
  enableParent(child_id) {
    let parent_id;
    this.isSelectAll = false;
    _.forEach(this.favourites[0].children, v => {
      _.forEach(v.children, val => {
        if (val.id == child_id) {
          v.checked = true;
          parent_id = v.id;
        }
      });
    });
    this.disableParent(parent_id);
  }

  /* If all child is checked false set parent to be false */
  disableParent(parent_id) {
    _.forEach(this.favourites[0].children, v => {
      if (v.id == parent_id) {
        setTimeout(() => {
          if (_.filter(v.children, ['checked', true]).length == 0) {
            v.checked = false;
          }
        }, 10);
      }
    });
  }

  /* Select All Fav Menu's in the popup */
  selectAllCheckBox(status) {
    _.forEach(this.favourites[0].children, v => {
      v.checked = !status;
      this.toggleChild(v.id, status);
    });
  }

  /* Hide and show Menu Item on mobile screen */
  hideSecondLevelMenu(val, option) {
    if (!val && option == 'close') {
      this.hideSecondLvlMnu = true;
      this.toggleMenuItems[0].selected = false;
    }
  }

  toggleItem(val: string, text: string, level: number) {
    this.toggleMenuItems[level].title = text;
    this.toggleMenuItems[level].selected = val ? false : true;
    this.hideSecondLvlMnu = false;
  }

  /* Get search text from form */
  searchForm(text: any) {
    if (text.headerSearchInput.length <= 2) {
      return;
    }
    this.searchFromSP(text.headerSearchInput);
  }

  /* Update Search text in Sharepoint List and run search query IF exists*/
  searchFromSP(searchText) {
    searchText = typeof searchText == 'object' ? searchText.headerSearchInput : searchText;
    if (searchText.length < 2) {
      return;
    }
    this.hideSearchModal = true;
    this.route.navigateByUrl('/search?t=' + searchText);
    this.hideSearchModal = false;
  }

  /* Returns popular search term */
  popuplarSearchTerm() {
    this.popuplarSearchList = [];
    const query = '?$orderby=count desc&$top=3';
    this.webService.getdata('searchList', query).subscribe(data => {
      this.popuplarSearchList = data['value'];
    });
  }

  /* To get the Auto Complete List for Advanced Search field */
  getAutoCompleteData() {
    const autoCompleteQuery = '?$select=Title';
    this.webService.getdata('searchList', autoCompleteQuery).subscribe(data => {
      if (data['value'] && data['value'].length > 0) {
        _.forEach(data['value'], val => {
          this.serachTitleList.push(val.Title);
        });
      }
    });
  }

  searchTerm(searchText) {
    this.filteredData = [];
    if (searchText == '' || searchText == undefined) {
      // this.showNoContent = false;
      return;
    }
    this.filteredData = _.filter(this.serachTitleList, function(o) {
      return _.includes(o.toLowerCase(), searchText.toLowerCase());
    });
    // this.showNoContent = this.filteredData.length > 0 ? false : true;
  }

  customNavigation(pageURL, menuName) {
    this.shareService.customNavigation(pageURL, menuName);
  }

  getCurrentDateTime() {
    this.currentTime = this.datePipe.transform(new Date(), 'dd-MM-yyyy HH:mm:ss');
  }
}

/* Popup modal */
@Directive({
  selector: '[appModal]'
})
export class DFModalDirective {
  constructor() {}
  @HostListener('click') modalOpen() {
    document.getElementById('myModal').classList.toggle('d-block');
  }
}

@Directive({
  selector: '[appSearchBarModal]'
})
export class DFSearchBarModalDirective {
  constructor() {}
  @HostListener('click') modalOpen() {
    document.getElementById('appSearchBarModal').classList.toggle('d-block');
  }
}
