import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutdfComponent } from './aboutdf.component';

describe('AboutdfComponent', () => {
  let component: AboutdfComponent;
  let fixture: ComponentFixture<AboutdfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutdfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutdfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
